import React, { useState } from 'react';

const BeforeAfter: React.FC = () => {
  const [showBefore, setShowBefore] = useState(false);

  return (
    <section className="py-20 bg-gray-50">
      <div className="container">
        <h2 className="section-title text-center">Our Transformation</h2>
        <p className="section-subtitle text-center">
          See the difference professional painting can make
        </p>

        <div className="relative max-w-4xl mx-auto mt-12">
          <div className="overflow-hidden rounded-lg shadow-xl">
            <img
              src={showBefore ? "/oldhouse.jpg" : "/newhouse.jpg"}
              alt={`${showBefore ? 'Before' : 'After'} transformation`}
              className="w-full h-auto"
            />
            
            <div className="absolute bottom-4 left-4 flex space-x-2">
              <button
                onClick={() => setShowBefore(true)}
                className={`px-4 py-2 font-medium rounded ${
                  showBefore 
                    ? 'bg-orange text-white' 
                    : 'bg-white text-navy'
                }`}
              >
                Before
              </button>
              <button
                onClick={() => setShowBefore(false)}
                className={`px-4 py-2 font-medium rounded ${
                  !showBefore 
                    ? 'bg-orange text-white' 
                    : 'bg-white text-navy'
                }`}
              >
                After
              </button>
            </div>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <img
              src="/room1.jpg"
              alt="Interior painting example"
              className="w-full h-64 object-cover rounded-lg shadow-md"
            />
            <img
              src="/room2.jpg"
              alt="Interior painting example"
              className="w-full h-64 object-cover rounded-lg shadow-md"
            />
            <img
              src="/room3.jpg"
              alt="Interior painting example"
              className="w-full h-64 object-cover rounded-lg shadow-md"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default BeforeAfter;